/* Copyright (C) 2018-2019 Greenbone Networks GmbH
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 */
import 'core-js/fn/object/keys';
import 'core-js/fn/object/values';

import {isString} from 'gmp/utils/identity';

import Languages, {getLanguageCodes} from '../languages';

describe('Language tests', () => {
  test('should contain list of languagegs', () => {
    expect(Object.keys(Languages).length).toEqual(2);

    let called = false;

    for (const lang of Object.values(Languages)) {
      called = true;

      expect(isString(lang.name)).toEqual(true);
      expect(isString(lang.native_name)).toEqual(true);
    }

    expect(called).toEqual(true);
  });
});

describe('getLanguageCodes test', () => {
  test('should return list of language codes', () => {
    const codes = getLanguageCodes();

    expect(codes.length).toEqual(2);

    let called = false;

    for (const code of codes) {
      called = true;
      expect(isString(code)).toEqual(true);
    }

    expect(called).toEqual(true);
  });
});

// vim: set ts=2 sw=2 tw=80:
